# Cloudify Utilities: Files

The files utility allows you to package a file with a blueprint and move it onto a managed Cloudify Compute node.



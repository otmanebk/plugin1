#!/usr/bin/env bash

ctx logger info "hello world"